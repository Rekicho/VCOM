To run the program execute the following command:
    python src/project.py <image_path>

    For example: python src/project.py multiple.jpg

    If you want to use the computer connected camera run without the <image_path>: python src/project.py

The program may take some time to answer because of the number of operations it does to improve the detection.

The image with the detected signs will shown and saved to output.png. The current one is an interesting example of an image taken from a computer camera.